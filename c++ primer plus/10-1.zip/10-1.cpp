#include "acount.h"
#include <iostream>
#include <cstring>
Account::Account()
{
    name="no";
    account="no";
    saving=0.0;
}
Account::Account( string na, string ac,double sa)
{
    name=na;
    account=ac;
    saving=sa;
}

Account::~Account(){
cout <<"bye!";
}
void Account::show() const {
    using namespace std;
cout<<"the name is: "<<name<<", the account is: "<<account<<", the saving is: "<<saving<<endl;
}sssss
    using std::endl;
    saving+=de;
    cout<<"now, you have "<<saving<<endl;
}
void Account::withdraw(double wi){
    using std::cout;
    using std::endl;
    saving-=wi;
    cout<<"now, you have "<<saving<<endl;
}
