#include "account.h"
#include <iostream>
#include <cstring>

Account::Account(string &na,string& ac,double sa){
    name=na;
    account=ac;
    saving=sa;
}
Account::Account(){
    name="no";
    account="no:;
    saving=0.0;
}
Account(){
cout <<"bye!"
}
void show(){
    using namespace std;
cout<<"the name is: "<<name<<", the account is: "<<account<<", the saving is: "<<saving<<endl;
}
void deposit(double de){
    using std::cout;
    using std::endl;
    saving+=de;
    cout<<"now, you have "<<saving<<endl;
}
void withdraw(double wi){
    using std::cout;
    using std::endl;
    saving-=wi;
    cout<<"now, you have "<<saving<<endl;
}
