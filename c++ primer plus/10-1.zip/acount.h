#ifndef ACOUNT_H_INCLUDED
#define ACOUNT_H_INCLUDED

#include <iostream>
#include <cstring>
using std::string;
class Account
{
    private:
        string name;
        string account;
        double saving;

    public:
        Account();
        Account( string na,string ac,double sa);
        ~Account();
        void show() const ;
        void deposit(double de);
        void withdraw(double wi);
};

#endif // ACOUNT_H_INCLUDED
