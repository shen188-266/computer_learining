#include <iostream>
#include "acount.h"
using namespace std;

int main()
{
 {

    Account yao;//=Account("yao dongwen","1814080231",2100);
    yao.show();
    yao.deposit(39.5);
    yao.show();
    yao.withdraw(231.4);
    yao.show();
 }
    return 0;
}
